# TokenTrim LLM Evaluation Testing Cycle — Implementation Plan

## Context

TokenTrim is a FastAPI gateway (cache → compress → route → generate) with an offline-capable stdlib `unittest` suite but no LLM evaluation harness. This plan adds the complete evaluation cycle — component, workflow, and application-level tests — using **unit-based** assertions plus **LLM-as-judge** scoring, over a golden dataset that includes **adversarial cases** targeting two confirmed weaknesses (see §7).

Nothing in this plan exists yet: `tests/eval/` has no files, no `.jsonl` datasets, and the case IDs from the prior discussion are unimplemented.

---

## 1. Prerequisite: fix the cache-hit bug

**File:** `app/pipeline.py:72-105`

The `baseline = ...` / `log_request(...)` / `return ChatResponse(...)` block sits outside `if hit is not None:` (line 72), so a cache miss raises `UnboundLocalError` (`latency_ms`, `hit` unbound). Dedent the block (lines 77-105) one level so it executes only on a real hit; a miss must fall through to compression.

Regression test: `test_cache_miss_no_unbound_local_error` in `tests/test_workflows.py`.

---

## 2. New files

```
tests/
  test_qwen_client.py, test_tokens.py, test_vectormath.py   # new component tests
  test_workflows.py                                         # new workflow tests
  test_api_live.py                                          # new, env-gated live tests
  eval/
    __init__.py
    fakes.py                # MappingFakeChatModel
    dataset_loader.py       # EvalCase + load_dataset()
    judge.py                # RuleBasedJudge, LLMJudge, make_judge()
    metrics.py              # tier_accuracy, cache_hit_f1, compression ratio, savings, judge score
    evaluate_pipeline.py    # CLI harness
    test_judge.py           # judge unit tests
    datasets/golden_v1.jsonl
frontend/vitest.config.js, frontend/src/App.test.jsx
.github/workflows/eval-live.yml
```

Extend: `tests/test_cache.py`, `test_compressor.py`, `test_router.py`, `test_embeddings.py`, `test_api.py`; `.github/workflows/ci.yml`; `frontend/package.json`.

---

## 3. Component-wise unit tests (offline, stdlib only)

- `test_qwen_client.py` — `FakeChatModel` answer/token behavior; `QwenChatModel` usage parsing with a mocked completion (incl. `cached_tokens` fallback).
- `test_tokens.py` — `estimate_tokens` / `estimate_message_tokens` edge cases.
- `test_vectormath.py` — cosine: identical=1, orthogonal=0, zero-vector=0.
- `test_cache.py` (extend) — store growth, lookup returns original query, exact-embed similarity = 1.0.
- `test_compressor.py` (extend) — compression reduces history tokens; rerank order with `HashingEmbeddingProvider`; query is last message in `build_prompt`.
- `test_router.py` (extend) — threshold boundaries (`at SIMPLE_MAX` → plus), pricing table completeness, naive-cost scaling.
- `test_embeddings.py` (extend) — hashing embedder determinism across instances.

## 4. Workflow tests (`tests/test_workflows.py`)

`Gateway` wired with `InMemoryVectorStore` + `HashingEmbeddingProvider` + `FakeChatModel` + temp stats log:

- `test_cache_miss_no_unbound_local_error` (regression for §1)
- `test_cache_hit_path` — 2nd identical query: `cached=True`, `cost_usd=0`, `similarity=1.0`
- `test_skip_cache_flag_bypasses_cache`
- `test_compression_path_saves_tokens` — `naive_cost_usd > cost_usd`; `breakdown.compressed.history < breakdown.uncompressed.history`
- `test_skip_compression_preserves_history`
- `test_forced_tier_overrides_router`
- `test_rag_rerank_path` — 4 chunks, top-k survive in prompt
- `test_simple_query_routes_to_flash` / `test_complex_query_routes_to_max`

## 5. Application-level tests

**Extend `tests/test_api.py`** (FastAPI `TestClient`, needs `httpx` in requirements):
- `/chat` with history + RAG; `skip_cache` over HTTP; `forced_tier` reflected in `model_used`; `/stats` reflects savings and request count; `naive_prompt`/`trimmed_prompt` shape.

**New `tests/test_api_live.py`** — `@unittest.skipUnless(os.getenv("TOKENTRIM_LIVE") == "1" and config.DASHSCOPE_API_KEY)`:
- live generation (cost > 0), live cache hit on repeat, live `/stats`.

## 6. LLM-as-judge (`tests/eval/judge.py`)

`JudgeScore` dataclass: `correctness, completeness, conciseness, hallucination_free, overall, explanation` (all floats 0–1 except explanation).

- **`RuleBasedJudge`** (offline, deterministic): correctness = golden substring present (case-insensitive); completeness = min(1, len ratio); conciseness = 1 if response ≤ 2.5× golden else linear decay; hallucination_free = correctness proxy; overall = weighted mean.
- **`LLMJudge`** (live): OpenAI-compatible client → Model Studio; judge model default `qwen-plus`, env `TOKENTRIM_JUDGE_MODEL`. Prompt contains query + golden + response, requests JSON `{correctness, completeness, conciseness, hallucination_free, explanation}` scored 1–5; strip markdown fences, parse JSON, regex fallback; normalize 1–5 → 0–1.
- `make_judge()` → `LLMJudge` iff `TOKENTRIM_JUDGE_LIVE=1` and API key present, else `RuleBasedJudge`.
- `tests/eval/test_judge.py` — rule-judge exact/partial, prompt contains rubric, JSON + fenced-JSON parsing, factory default.

## 7. Golden dataset with adversarial cases

**File:** `tests/eval/datasets/golden_v1.jsonl` (~20 cases). Schema:

```json
{
  "id": "compression-adversarial-01",
  "category": "adversarial/compression",
  "query": "What is my booking reference number?",
  "warmup_query": null,
  "history": [ ... ],
  "rag_chunks": [],
  "golden_answer": "Your booking reference is XJF-2209.",
  "expectations": {
    "cache_hit_after_warmup": null,
    "expected_model_tier": null,
    "required_in_trimmed_prompt": ["XJF-2209"],
    "required_in_naive_prompt": ["XJF-2209"]
  },
  "known_limitation": true,
  "judge": { "min_overall": 0.7 }
}
```

**Standard cases** (happy path): `cache-exact-01`, `cache-paraphrase-01`, `routing-simple/medium/complex-01`, `compression-history-01`, `compression-rag-01`, `forced-tier-01`, `skip-cache-01`, `skip-compression-01`, `code-question-01`, `multi-turn-01`, `empty-rag-01`, `empty-history-01`.

### Adversarial case A — compressed-away fact (`compression-adversarial-01`)

- 10-turn history, turns 1–8 each ~120 chars; load-bearing fact in **turn 4** (cumulative offset > 400 chars): "One more thing — my booking reference is XJF-2209, please keep it on file."
- Final query references only that fact: "What is my booking reference number?"
- Mechanics (verified against `app/compressor.py:38-47`): `compress_history` folds turns 1–8 into `joined[:400]`; turn 4 sits past the cut → fact absent from `trimmed_prompt`, present in `naive_prompt`.
- Assertions: `required_in_naive_prompt` passes (fact exists raw), `required_in_trimmed_prompt` **fails** → finding: *fold-truncate destroys entities that later queries depend on, silently.*
- `known_limitation: true` — reported as a surfaced finding, not a broken suite. In live mode the real model cannot answer (fact not in prompt) and `LLMJudge` correctness goes low, confirming end-to-end.

### Adversarial case B — cache false-positive (`cache-adversarial-short-01`, `cache-adversarial-long-01`)

Mechanics (verified against `app/config.py:63` + `app/embeddings.py`): hashing embeddings are L2-normalized bag-of-words; near-duplicates sharing *n* tokens with 1 differing token score ≈ n/(n+1); threshold is 0.92.

- **`cache-adversarial-short-01`** (guards threshold, passes): warmup "What is the refund policy for laptops?", eval "…for phones?" — 6/7 shared ≈ 0.86 < 0.92 → correctly no hit. Expectation `cache_hit_after_warmup: false` + `warmup_query` set.
- **`cache-adversarial-long-01`** (known limitation, fails today): ~22-token near-duplicate differing only in "laptops" vs "phones" ≈ 0.96 ≥ 0.92 → **false hit**: laptop answer served for phone question. Expectation `cache_hit_after_warmup: false`, `known_limitation: true`.
- Finding: *the 0.92 cutoff only rejects near-duplicates with ≤ 11 shared tokens; entity-swapped long queries return wrong cached answers.* New `warmup_query` field lets the harness warm the cache with a different query than the one evaluated.

Both adversarial findings are demo-worthy report content: quantified, reproducible offline, confirmed live.

## 8. Evaluation harness (`tests/eval/`)

- `fakes.py` — `MappingFakeChatModel(ChatModel)`: maps query → golden answer (offline judge has real signal).
- `dataset_loader.py` — `EvalCase` dataclass mirroring §7 schema; `load_dataset(path)`.
- `metrics.py` — `tier_accuracy`, `cache_hit_f1` (precision/recall over `cache_hit_after_warmup`), `avg_compression_ratio`, `avg_savings_pct`, `avg_judge_score`, `known_limitations_count`.
- `evaluate_pipeline.py` — CLI:

```bash
python -m tests.eval.evaluate_pipeline \
  --dataset tests/eval/datasets/golden_v1.jsonl \
  --output eval-report.json --assert-thresholds
```

Per case: optional warmup with `warmup_query` (else the query itself when `cache_hit_after_warmup` expected true), run `gateway.chat(...)`, assert prompt-content expectations, judge response vs golden. Report JSON includes per-case results + observed similarities (quantifies finding B) + findings section. Gate: fails only on **unexpected** failures; `known_limitation` cases that pass are flagged `limitation_resolved`.

Offline gate thresholds: tier accuracy ≥ 0.85, cache hit F1 ≥ 0.80 (over non-limitation cases), avg compression ratio > 1.2, savings > 0, judge overall ≥ 0.70. Live gate: judge ≥ 3.5/5, tier ≥ 0.80, cache F1 ≥ 0.70.

## 9. CI/CD

- `.github/workflows/ci.yml`: install `httpx`; `TOKENTRIM_OFFLINE=1 python -m unittest discover -s tests -t . -p "test_*.py"`; run offline harness with `--assert-thresholds`; upload `eval-report.json`; frontend job (`npm ci`, lint, build, `npm test`).
- `.github/workflows/eval-live.yml`: `workflow_dispatch` only; `TOKENTRIM_JUDGE_LIVE=1` + `DASHSCOPE_API_KEY` secret; upload live report.

## 10. Frontend tests

`frontend/package.json`: add `test`/`test:watch` scripts + devDeps (`vitest`, `@testing-library/react`, `@testing-library/jest-dom`, `jsdom`). `vitest.config.js`: jsdom + React plugin. `src/App.test.jsx`: renders heading, invalid-history-JSON error, mocked `/chat` fetch displays metrics, tokens-saved calculation.

## 11. Verification

```bash
pip install httpx
TOKENTRIM_OFFLINE=1 python -m unittest discover -s tests -t . -p "test_*.py"
TOKENTRIM_OFFLINE=1 python -m tests.eval.evaluate_pipeline --dataset tests/eval/datasets/golden_v1.jsonl --output eval-report.json --assert-thresholds
# optional live:
TOKENTRIM_JUDGE_LIVE=1 DASHSCOPE_API_KEY=... python -m tests.eval.evaluate_pipeline ... --output eval-live-report.json
cd frontend && npm test
```

Passing = unittest exits 0; harness exits 0 with the two `known_limitation` cases reported as findings (not gate failures); report contains observed cache similarities for case B; frontend tests green.

## Critical files

- `app/pipeline.py` — §1 bug fix (lines 72–105 dedent)
- `tests/eval/judge.py`, `evaluate_pipeline.py`, `datasets/golden_v1.jsonl` — the core new surface
- `tests/test_workflows.py` — layer-integration + regression tests
- `frontend/vitest.config.js`, `frontend/src/App.test.jsx`, both workflow YAMLs