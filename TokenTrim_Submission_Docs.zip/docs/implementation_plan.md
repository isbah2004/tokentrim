# TokenTrim — LLM Evaluation Testing Cycle Implementation

Based on [Hashirs_Suggestion.md](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/docs/Hashirs_Suggestion.md), this plan adds a complete evaluation testing cycle to TokenTrim: bug fix → component tests → workflow tests → evaluation harness with LLM-as-judge → golden dataset with adversarial cases → CI/CD → frontend tests.

## Current State

- **Backend**: FastAPI gateway at [`app/`](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/app) — cache → compress → route → generate pipeline
- **Tests**: 9 existing test files in [`tests/`](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/tests) — basic unit tests, all offline stdlib `unittest`
- **Frontend**: React + Vite at [`frontend/`](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/frontend) — no tests at all
- **CI**: Minimal [`ci.yml`](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/.github/workflows/ci.yml) — runs unit tests only, no eval harness, no frontend

> [!IMPORTANT]
> **Confirmed Bug**: [`pipeline.py` lines 77–105](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/app/pipeline.py#L77-L105) — the `baseline = ...` / `log_request(...)` / `return ChatResponse(...)` block is indented at the `if not skip_cache:` level instead of inside `if hit is not None:`. A cache miss triggers `UnboundLocalError` because `latency_ms` and `hit` are unbound. This must be fixed first.

---

## Proposed Changes

### Phase 1 — Bug Fix & Regression Test

#### [MODIFY] [pipeline.py](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/app/pipeline.py)
- **Dedent lines 77–105** one level (from 8 → 12 spaces) so the `baseline`/`log_request`/`return` block only executes inside `if hit is not None:`
- A cache miss now correctly falls through to Layer 2 (compression)

#### [NEW] [test_workflows.py](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/tests/test_workflows.py)
- `test_cache_miss_no_unbound_local_error` — regression test ensuring a non-cached query doesn't crash
- Full Gateway wired with `InMemoryVectorStore` + `HashingEmbeddingProvider` + `FakeChatModel` + temp stats log
- Additional workflow tests:
  - `test_cache_hit_path` — 2nd identical query returns `cached=True`, `cost_usd=0`, `similarity=1.0`
  - `test_skip_cache_flag_bypasses_cache`
  - `test_compression_path_saves_tokens` — `naive_cost_usd > cost_usd`
  - `test_skip_compression_preserves_history`
  - `test_forced_tier_overrides_router`
  - `test_rag_rerank_path` — 4 chunks, top-k survive in prompt
  - `test_simple_query_routes_to_flash` / `test_complex_query_routes_to_max`

---

### Phase 2 — Component Unit Tests (Extend Existing)

#### [NEW] [test_qwen_client.py](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/tests/test_qwen_client.py)
- `FakeChatModel` answer/token behavior
- `QwenChatModel` usage parsing with a mocked completion (incl. `cached_tokens` fallback)

#### [NEW] [test_tokens.py](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/tests/test_tokens.py)
- `estimate_tokens` / `estimate_message_tokens` edge cases (empty, unicode, long inputs)

#### [NEW] [test_vectormath.py](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/tests/test_vectormath.py)
- Cosine similarity: identical=1, orthogonal=0, zero-vector=0

#### [MODIFY] [test_cache.py](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/tests/test_cache.py)
- Store growth assertions, lookup returns original query, exact-embed similarity = 1.0

#### [MODIFY] [test_compressor.py](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/tests/test_compressor.py)
- Compression reduces history tokens; rerank order with `HashingEmbeddingProvider`; query is last message in `build_prompt`

#### [MODIFY] [test_router.py](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/tests/test_router.py)
- Threshold boundaries (`at SIMPLE_MAX` → plus), pricing table completeness, naive-cost scaling

#### [MODIFY] [test_embeddings.py](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/tests/test_embeddings.py)
- Hashing embedder determinism across instances

---

### Phase 3 — Evaluation Harness (Core New Surface)

#### [NEW] `tests/eval/__init__.py`
Empty init

#### [NEW] `tests/eval/fakes.py`
- `MappingFakeChatModel(ChatModel)` — maps query → golden answer for offline deterministic judging

#### [NEW] `tests/eval/dataset_loader.py`
- `EvalCase` dataclass mirroring the JSONL schema (id, category, query, warmup_query, history, rag_chunks, golden_answer, expectations, known_limitation, judge)
- `load_dataset(path)` — reads `.jsonl`, returns `list[EvalCase]`

#### [NEW] `tests/eval/judge.py`
- `JudgeScore` dataclass: correctness, completeness, conciseness, hallucination_free, overall, explanation
- **`RuleBasedJudge`** (offline, deterministic): correctness = golden substring present; completeness = length ratio; conciseness = linear decay; overall = weighted mean
- **`LLMJudge`** (live): OpenAI-compatible client → Model Studio; judge model `qwen-plus` (env-configurable); JSON response parsing with regex fallback
- `make_judge()` factory — LLMJudge if `TOKENTRIM_JUDGE_LIVE=1` and API key present, else RuleBasedJudge

#### [NEW] `tests/eval/metrics.py`
- `tier_accuracy`, `cache_hit_f1`, `avg_compression_ratio`, `avg_savings_pct`, `avg_judge_score`, `known_limitations_count`

#### [NEW] `tests/eval/evaluate_pipeline.py`
- CLI harness: `python -m tests.eval.evaluate_pipeline --dataset <path> --output <report.json> --assert-thresholds`
- Per case: optional warmup → `gateway.chat(...)` → assert prompt-content expectations → judge response vs golden
- Offline gate thresholds: tier accuracy ≥ 0.85, cache hit F1 ≥ 0.80, compression ratio > 1.2, savings > 0, judge overall ≥ 0.70
- Known limitation cases don't gate-fail; if they pass, flagged `limitation_resolved`

#### [NEW] `tests/eval/test_judge.py`
- Rule-judge exact/partial, prompt rubric assertions, JSON + fenced-JSON parsing, factory default behavior

#### [NEW] `tests/eval/datasets/golden_v1.jsonl`
- ~20 test cases (12 standard happy path + 3 adversarial)
- **Standard**: cache-exact, cache-paraphrase, routing-simple/medium/complex, compression-history, compression-rag, forced-tier, skip-cache, skip-compression, code-question, multi-turn, empty-rag, empty-history
- **Adversarial A** (`compression-adversarial-01`): 10-turn history with load-bearing fact in turn 4 that gets truncated by `compress_history` — `known_limitation: true`
- **Adversarial B** (`cache-adversarial-short-01`): short near-duplicate passes threshold (6/7 shared ≈ 0.86 < 0.92) — should pass
- **Adversarial B** (`cache-adversarial-long-01`): long near-duplicate fails (22 tokens, ≈ 0.96 ≥ 0.92) — `known_limitation: true`

---

### Phase 4 — Application-Level Tests

#### [MODIFY] [test_api.py](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/tests/test_api.py)
- Add FastAPI `TestClient` tests: `/chat` with history + RAG, `skip_cache` over HTTP, `forced_tier` reflected in `model_used`, `/stats` reflects savings, `naive_prompt`/`trimmed_prompt` shape

#### [NEW] [test_api_live.py](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/tests/test_api_live.py)
- `@unittest.skipUnless(os.getenv("TOKENTRIM_LIVE") == "1" and config.DASHSCOPE_API_KEY)`
- Live generation (cost > 0), live cache hit on repeat, live `/stats`

---

### Phase 5 — Frontend Tests

#### [MODIFY] [package.json](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/frontend/package.json)
- Add `test` / `test:watch` scripts
- Add devDeps: `vitest`, `@testing-library/react`, `@testing-library/jest-dom`, `jsdom`

#### [NEW] `frontend/vitest.config.js`
- jsdom environment + `@vitejs/plugin-react`

#### [NEW] `frontend/src/App.test.jsx`
- Renders heading, invalid-history-JSON error, mocked `/chat` fetch displays metrics, tokens-saved calculation

---

### Phase 6 — CI/CD Pipelines

#### [MODIFY] [ci.yml](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/.github/workflows/ci.yml)
- Add `httpx` to pip install
- Run offline harness with `--assert-thresholds` after unit tests
- Upload `eval-report.json` as artifact
- Add frontend job: `npm ci` → lint → build → `npm test`

#### [NEW] `.github/workflows/eval-live.yml`
- `workflow_dispatch` only (manual trigger)
- Env: `TOKENTRIM_JUDGE_LIVE=1` + `DASHSCOPE_API_KEY` from secrets
- Upload live eval report as artifact

---

### Phase 7 — Dependency Update

#### [MODIFY] [requirements.txt](file:///Users/syedisbah/Documents/ZyphramProjects/token_optimizer/requirements.txt)
- Add `httpx` (needed for FastAPI `TestClient`)

---

## Open Questions

> [!IMPORTANT]
> **Q1**: Hashir's doc mentions `qwen-plus` as the default judge model. Should we keep that or make it a different model? The env var `TOKENTRIM_JUDGE_MODEL` lets you override it either way.

> [!IMPORTANT]
> **Q2**: The adversarial cases document two confirmed weaknesses (compression truncation and cache false-positive). These are marked `known_limitation: true` so they don't break CI. Do you want us to also attempt to **fix** these weaknesses as a follow-up, or purely surface them as findings for now?

> [!NOTE]
> **Q3**: The golden dataset starts with ~20 cases. Should we add more domain-specific cases (e.g., Urdu/multilingual, very long context) for your demo, or is the standard + adversarial set sufficient?

---

## Verification Plan

### Automated Tests

```bash
# 1. Install httpx
pip install httpx

# 2. Run all unit + workflow tests (offline)
TOKENTRIM_OFFLINE=1 python -m unittest discover -s tests -t . -p "test_*.py"

# 3. Run eval harness (offline)
TOKENTRIM_OFFLINE=1 python -m tests.eval.evaluate_pipeline \
  --dataset tests/eval/datasets/golden_v1.jsonl \
  --output eval-report.json --assert-thresholds

# 4. Frontend tests
cd frontend && npm test

# 5. (Optional) Live eval
TOKENTRIM_JUDGE_LIVE=1 DASHSCOPE_API_KEY=... python -m tests.eval.evaluate_pipeline \
  --dataset tests/eval/datasets/golden_v1.jsonl \
  --output eval-live-report.json
```

### Pass Criteria

| Check | Expected |
|-------|----------|
| Unit tests | Exit 0 |
| Eval harness (offline) | Exit 0; 2 `known_limitation` cases reported as findings, not failures |
| Tier accuracy | ≥ 0.85 |
| Cache hit F1 | ≥ 0.80 (non-limitation cases) |
| Compression ratio | > 1.2 |
| Judge overall | ≥ 0.70 |
| Frontend tests | Green |
| CI pipeline | Both jobs (backend + frontend) green |

### Manual Verification
- Review `eval-report.json` to confirm adversarial findings are clearly documented
- Verify the cache false-positive case shows observed similarity scores
- Confirm the compression-truncation case shows the fact missing from trimmed prompt
